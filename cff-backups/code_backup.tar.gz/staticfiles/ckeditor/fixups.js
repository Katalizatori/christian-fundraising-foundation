// Stop nagging.
CKEDITOR.config.versionCheck = false
// Stop attaching yourself to any inline with a contenteditable attribute (???)
CKEDITOR.disableAutoInline = true
