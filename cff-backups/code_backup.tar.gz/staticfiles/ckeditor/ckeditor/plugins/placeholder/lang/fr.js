﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","fr",{title:"Propriétés de l'Espace réservé",toolbar:"Créer l'Espace réservé",name:"Nom de l'espace réservé",invalidName:"L'espace réservé ne peut pas être vide ni contenir l'un de ses caractères : [, ], <, >",pathName:"espace réservé"});