﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","zh",{title:"UI 色彩選擇器",preview:"即時預覽",config:"請將此段字串複製到您的 config.js 檔案中。",predefined:"設定預先定義的色彩"});